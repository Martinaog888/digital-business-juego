(() => {
"use strict";
const $ = id => document.getElementById(id);
const palette = ["#f9b0b2","#f6cc6b","#96d8c4","#b5a3ee"];
const keys = ["KeyA","KeyF","KeyJ","KeyL"];
const labels = ["A","F","J","L"];
const animalNames = ["Panda", "Dragón", "Perro", "Conejo"];
// Ilustraciones vectoriales locales: se escalan sin perder nitidez.
function animalSvg(id) {
 const bodies = [
 '<circle cx="26" cy="34" r="12" fill="#343547"/><circle cx="64" cy="34" r="12" fill="#343547"/><ellipse cx="45" cy="77" rx="23" ry="24" fill="#fffaf3"/><ellipse cx="28" cy="97" rx="12" ry="7" fill="#343547"/><ellipse cx="62" cy="97" rx="12" ry="7" fill="#343547"/><ellipse cx="23" cy="76" rx="8" ry="13" fill="#343547" transform="rotate(25 23 76)"/><ellipse cx="67" cy="76" rx="8" ry="13" fill="#343547" transform="rotate(-25 67 76)"/><rect x="17" y="30" width="56" height="46" rx="23" fill="#fffaf3"/><ellipse cx="33" cy="49" rx="10" ry="12" fill="#343547" transform="rotate(20 33 49)"/><ellipse cx="57" cy="49" rx="10" ry="12" fill="#343547" transform="rotate(-20 57 49)"/>',
 '<path d="M26 70 Q5 46 9 81 L23 91M64 70 Q85 46 81 81 L67 91" fill="#b6a0f3" stroke="#715299" stroke-width="2"/><path d="M61 89 Q87 97 75 71 Q94 96 70 101" fill="#75cbb0"/><ellipse cx="45" cy="78" rx="24" ry="24" fill="#79cfb1"/><ellipse cx="45" cy="83" rx="14" ry="17" fill="#ffdf99"/><ellipse cx="29" cy="98" rx="13" ry="6" fill="#69bda2"/><ellipse cx="61" cy="98" rx="13" ry="6" fill="#69bda2"/><path d="M26 34 L24 16 Q37 19 37 34M54 34 Q55 19 68 16 L64 37" fill="#ffe1a0"/><rect x="16" y="29" width="58" height="47" rx="22" fill="#84dabc"/><path d="M40 29 L45 19 L50 29" fill="#b6a0f3"/><ellipse cx="45" cy="63" rx="22" ry="13" fill="#a4e6c9"/><circle cx="37" cy="60" r="2" fill="#468d76"/><circle cx="53" cy="60" r="2" fill="#468d76"/>',
 '<ellipse cx="45" cy="78" rx="22" ry="24" fill="#efba78"/><ellipse cx="45" cy="83" rx="14" ry="15" fill="#fff0d5"/><ellipse cx="29" cy="98" rx="12" ry="6" fill="#c68b58"/><ellipse cx="61" cy="98" rx="12" ry="6" fill="#c68b58"/><path d="M65 83 Q88 74 77 65" fill="none" stroke="#c68b58" stroke-width="9" stroke-linecap="round"/><rect x="19" y="30" width="52" height="46" rx="23" fill="#f4c58c"/><ellipse cx="20" cy="48" rx="11" ry="23" fill="#a67351" transform="rotate(13 20 48)"/><ellipse cx="70" cy="48" rx="11" ry="23" fill="#a67351" transform="rotate(-13 70 48)"/><path d="M39 32 Q45 25 51 32 L51 57 L39 57Z" fill="#fff0d5"/><ellipse cx="45" cy="64" rx="18" ry="12" fill="#fff0d5"/>',
 '<ellipse cx="45" cy="80" rx="23" ry="23" fill="#e2d6fb"/><circle cx="69" cy="83" r="10" fill="#fff9ff"/><ellipse cx="29" cy="98" rx="13" ry="6" fill="#c8b1ed"/><ellipse cx="61" cy="98" rx="13" ry="6" fill="#c8b1ed"/><ellipse cx="31" cy="25" rx="10" ry="24" fill="#e2d6fb" transform="rotate(-9 31 25)"/><ellipse cx="59" cy="25" rx="10" ry="24" fill="#e2d6fb" transform="rotate(9 59 25)"/><ellipse cx="31" cy="24" rx="4.5" ry="17" fill="#f3adc8" transform="rotate(-9 31 24)"/><ellipse cx="59" cy="24" rx="4.5" ry="17" fill="#f3adc8" transform="rotate(9 59 24)"/><rect x="18" y="36" width="54" height="42" rx="22" fill="#eee4ff"/><ellipse cx="45" cy="81" rx="13" ry="14" fill="#fff9ff"/>'
 ];
 return '<svg class="animal-art animal-'+id+'" viewBox="0 0 90 110" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><ellipse cx="45" cy="105" rx="27" ry="3" fill="#584270" opacity=".12"/>'+bodies[id]+
 '<g class="animal-eyes" fill="'+(id===0?'#ffffff':'#49384f')+'"><ellipse cx="33" cy="50" rx="3" ry="4"/><ellipse cx="57" cy="50" rx="3" ry="4"/></g><g class="animal-happy-eyes" fill="none" stroke="'+(id===0?'#ffffff':'#49384f')+'" stroke-width="2.5" stroke-linecap="round"><path d="M29 51 Q33 44 37 51M53 51 Q57 44 61 51"/></g><g fill="#f39bb4" opacity=".65"><ellipse cx="26" cy="60" rx="5" ry="3"/><ellipse cx="64" cy="60" rx="5" ry="3"/></g>'+
 (id!==1?'<path d="M41 58 Q45 55 49 58 Q48 62 45 63 Q42 62 41 58" fill="'+(id===3?'#d584a7':'#49384f')+'"/>':'')+
 '<path class="animal-smile" d="M39 66 Q45 72 51 66" fill="none" stroke="#49384f" stroke-width="2" stroke-linecap="round"/><path class="animal-sad" d="M40 70 Q45 64 50 70" fill="none" stroke="#49384f" stroke-width="2" stroke-linecap="round"/><g class="animal-cheer"><path d="M38 65 Q45 79 52 65Z" fill="#693b62"/><path d="M41 70 Q45 67 49 70 Q45 75 41 70" fill="#f49bb8"/></g><g class="animal-crown" fill="#ffd66d" stroke="#c99531" stroke-width="1.2"><path d="M31 30 L28 18 L39 23 L45 13 L51 23 L62 18 L59 30Z"/></g></svg>';
}


const model = new ChairGame(4);
let count=4, roundTimer=null, audio=null, master=null, musicBus=null, beatTimer=null, noteIndex=0, busy=false, muted=false, stopAt=0;
const melody=[72,76,79,76,74,77,81,77,72,76,79,84,83,79,77,74];
const selectButtons=[...document.querySelectorAll("[data-count]")];
function message(title,description,icon="♫") { $("stage-title").textContent=title; $("stage-description").textContent=description; $("stage-icon").textContent=icon; }
function tone(midi,duration=.15,type="triangle",volume=.12,bus=master) {
 if(!audio || audio.state!=="running" || !bus) return;
 const oscillator=audio.createOscillator(), gain=audio.createGain(), now=audio.currentTime;
 oscillator.type=type; oscillator.frequency.value=440*Math.pow(2,(midi-69)/12);
 gain.gain.setValueAtTime(0,now); gain.gain.linearRampToValueAtTime(volume,now+.008);gain.gain.exponentialRampToValueAtTime(.001,now+duration);
 oscillator.connect(gain);gain.connect(bus);oscillator.start(now);oscillator.stop(now+duration+.01);
 oscillator.onended=()=>{oscillator.disconnect();gain.disconnect();};
}
async function unlockAudio() {
 try {
  if(!audio){const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio) throw Error("No disponible");audio=new Audio();master=audio.createGain();master.gain.value=muted?0:.65;master.connect(audio.destination);}
  if(audio.state!=="running") await audio.resume();
  return audio.state==="running";
 } catch (_) { $("status").textContent="Audio no disponible: sigue la señal visual «¡Siéntate!»."; return false; }
}
function endMusic() {
 clearInterval(beatTimer);beatTimer=null;
 if(musicBus){musicBus.gain.cancelScheduledValues(audio.currentTime);musicBus.gain.setValueAtTime(0,audio.currentTime);const old=musicBus;setTimeout(()=>old.disconnect(),300);musicBus=null;}
}
function music() {
 endMusic();if(!audio||audio.state!=="running")return;
 musicBus=audio.createGain();musicBus.connect(master);noteIndex=0;
 const beat=()=>{tone(melody[noteIndex%melody.length],.16,"triangle",.12,musicBus);if(noteIndex%2===0)tone([48,53,48,55][Math.floor(noteIndex/4)%4],.18,"sine",.17,musicBus);noteIndex++;};
 beat();beatTimer=setInterval(beat,210);
}
function stopRound() {
 if(!model.stopMusic())return;
 clearTimeout(roundTimer);endMusic();$("arena").classList.remove("dancing");$("arena").classList.add("stopped");
 message("¡Siéntate!","Pulsa tu tecla. ¡Cada milisegundo cuenta!","!");
 $("status").textContent="¡La música ha parado! Consigue tu silla.";renderStats();
}
function renderStats() {
 const alive=model.active.length;
 const available=(model.phase==="result"||model.phase==="finished")?0:Math.max(0,model.chairs-model.claims.length);
 $("remaining").textContent=available+" silla"+(available===1?"":"s")+" · "+alive+" personas";
 $("round").textContent=model.round ? "RONDA "+model.round+" / "+(count-1) : "PREPARA TU PARTIDA";
 $("scores").innerHTML=model.players.map(p=>'<div class="score-row '+(p.id===model.winner?"winner":"")+'"><span>Jugador '+(p.id+1)+'</span><span>'+(p.id===model.winner?"★ Ganador · ":!p.active?"Fuera · ":"")+p.seats+' silla'+(p.seats===1?"":"s")+'</span></div>').join("");
}
function renderPeople() {
 $("roster").innerHTML=model.players.map(p=>'<div class="roster-row" style="--player:'+palette[p.id]+'"><span class="avatar" aria-hidden="true">'+animalSvg(p.id)+'</span><span>Jugador '+(p.id+1)+' <span class="animal-name">· '+animalNames[p.id]+'</span></span><kbd>'+labels[p.id]+'</kbd></div>').join("");
 $("characters").innerHTML=model.players.map(p=>'<div class="character" id="person-'+p.id+'" style="--player:'+palette[p.id]+';--delay:-'+p.id*.13+'s"><div class="creature" role="img" aria-label="'+animalNames[p.id]+'">'+animalSvg(p.id)+'</div><span class="player-tag"><kbd>'+labels[p.id]+'</kbd> J'+(p.id+1)+'</span></div>').join("");
}
function renderChairs() { $("chairs").innerHTML=Array.from({length:model.chairs},()=>'<div class="chair"><i></i></div>').join(""); }
function positionPeople(time=0) {
 const playing=model.phase==="music";
 model.players.forEach(p=>{
  const element=$("person-"+p.id);if(!element)return;
  const seat=model.claims.indexOf(p.id);
  let x,y;
  if(seat>=0){const chairCount=document.querySelectorAll(".chair").length;x=50+((seat-(chairCount-1)/2)*71/$("arena").clientWidth)*100;y=58;}
  else{const angle=(p.id/count)*Math.PI*2-Math.PI*.78+(playing?time/1800:0);x=50+Math.cos(angle)*35;y=51+Math.sin(angle)*31;}
  element.style.left=x+"%";element.style.top=y+"%";element.classList.toggle("out",!p.active);element.classList.toggle("winner",p.id===model.winner);element.classList.toggle("seated",seat>=0);
 });
}
function animate(time){if(model.phase==="music") positionPeople(time);requestAnimationFrame(animate);}
function clearEffects(){clearTimeout(roundTimer);roundTimer=null;endMusic();$("arena").classList.remove("dancing","stopped");$("confetti").innerHTML="";}
function resetGame(newCount=count) {
 clearEffects();count=newCount;model.reset(count);busy=false;
 selectButtons.forEach(b=>{const selected=Number(b.dataset.count)===count;b.classList.toggle("selected",selected);b.setAttribute("aria-pressed",String(selected));b.disabled=false;});
 renderPeople();renderChairs();positionPeople();renderStats();message("Todo listo para bailar","Reúne a tu equipo y dale al play.");
 $("status").textContent="Elige cuántas personas vais a jugar.";$("play").disabled=false;$("play").innerHTML="Empezar partida <span>↗</span>";$("reset").hidden=true;
}
async function startRound() {
 if(busy||!["ready","result","paused"].includes(model.phase))return;
 busy=true;$("play").disabled=true;
 const soundReady=await unlockAudio();
 busy=false;
 if(document.hidden){$("play").disabled=false;return;}
 if(!model.startRound())return;
 clearEffects();selectButtons.forEach(b=>b.disabled=true);
 renderChairs();positionPeople();renderStats();$("arena").classList.add("dancing");
 message("¡Sigue el ritmo!","Espera… la música puede parar en cualquier momento.");
 $("status").textContent=soundReady?"No pulses hasta que se detenga la música.":"Sigue la señal visual: espera a «¡Siéntate!»."; 
 $("play").innerHTML="La ronda está en marcha ♫";$("reset").hidden=false;
 music();
 stopAt=performance.now()+4500+Math.random()*4500;
 roundTimer=setTimeout(stopRound,Math.max(0,stopAt-performance.now()));
}
function claim(id,repeat) {
 const result=model.press(id,repeat);
 if(result.type==="early"){$("status").textContent="Jugador "+(id+1)+": ¡todavía no! Suelta la tecla y espera.";return;}
 if(!["seat","elimination"].includes(result.type))return;
 const index=model.claims.indexOf(id),chair=$("chairs").children[index];
 if(chair){chair.classList.add("taken");chair.style.setProperty("--player",palette[id]);}
 positionPeople();renderStats();tone(80+index*3,.11,"sine",.11);
 if(result.type==="seat"){$("status").textContent="Jugador "+(id+1)+" ya tiene silla. ¡Aún queda sitio!";return;}
 clearEffects();positionPeople();
 $("status").textContent="Jugador "+(result.loser+1)+" se ha quedado sin silla en la ronda "+model.round+".";
 if(model.phase==="finished"){
  message("¡Gana el jugador "+(model.winner+1)+"!","Reflejos de campeón. ¿Os atrevéis con la revancha?","★");
  $("play").disabled=false;$("play").innerHTML="Volver a jugar <span>↻</span>";$("reset").hidden=true;
  $("confetti").innerHTML=Array.from({length:32},(_,i)=>'<i class="confetto" style="--left:'+((i*37)%100)+'%;--color:'+palette[i%4]+';--duration:'+(2+i%4*.4)+'s;--delay:-'+(i%7*.3)+'s"></i>').join("");
 } else {
  message("¡Una silla menos!","Jugador "+(result.loser+1)+" queda eliminado. Seguimos bailando.","↗");
  $("play").disabled=false;$("play").innerHTML="Siguiente ronda <span>↗</span>";
 }
}
selectButtons.forEach(b=>b.addEventListener("click",()=>{if(model.phase==="ready")resetGame(Number(b.dataset.count));}));
$("play").addEventListener("click",()=>{if(model.phase==="finished"){resetGame();}else startRound();});
$("reset").addEventListener("click",()=>resetGame());
$("sound").addEventListener("click",async()=>{muted=!muted;if(master)master.gain.setValueAtTime(muted?0:.65,audio.currentTime);$("sound").textContent=muted?"♫ Sonido desactivado":"♫ Sonido activado";$("sound").setAttribute("aria-pressed",String(!muted));if(!muted)await unlockAudio();});
window.addEventListener("keydown",event=>{
 if(event.ctrlKey||event.metaKey||event.altKey)return;
 let id=keys.indexOf(event.code);
 if(id<0)id=labels.indexOf(event.key.toUpperCase());
 if(id<0||id>=count)return;
 event.preventDefault();
 // Si el hilo del navegador se ha retrasado, primero se aplica la parada pendiente.
 if(model.phase==="music"&&performance.now()>=stopAt)stopRound();
 claim(id,event.repeat);
});
window.addEventListener("keyup",event=>{let id=keys.indexOf(event.code);if(id<0)id=labels.indexOf(event.key.toUpperCase());model.release(id);});
function suspendRound(){
 if(!model.pause()) {model.held.clear();return;}
 clearEffects();renderChairs();positionPeople();renderStats();message("Una pausa para todos","La ronda se repetirá cuando estéis preparados.","Ⅱ");
 $("status").textContent="Ronda anulada al salir de la ventana. Nadie queda eliminado.";
 $("play").disabled=false;$("play").innerHTML="Repetir ronda <span>↗</span>";
}
document.addEventListener("visibilitychange",()=>{if(document.hidden)suspendRound();});
window.addEventListener("blur",suspendRound);
resetGame();requestAnimationFrame(animate);
})();

